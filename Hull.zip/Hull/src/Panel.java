
//Used http://www.ahristov.com/tutorial/geometry-games/convex-hull.html for help on Quickhull

import javax.swing.JPanel;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;
import java.util.ArrayList;
import java.awt.Point;

public abstract class Panel extends JPanel{
	
	protected final int TOTAL_POINTS = 100;		//Total points that will be used for reference
	protected ArrayList<Point> list;			//Stores a list of points 
	protected ArrayList<Point> hull;			//This will store the points attributed to the convex hull
	
	
	//This function will be used by it's children to draw lines from algorithm
	protected abstract void SetLines(Graphics g);
	
	//Default Constructor
	public Panel() {
		GeneratePoints();
	}
	
	//This will take list and populate it with random numbers
	//Points will only range from 50-650 to make them appear on screen easier
	private void GeneratePoints(){
		list = new ArrayList<Point>();		//Creates a new list, garbage collector should grab old list if existed
		Random rand = new Random();				//Used for random function
		
		for(int i = 0; i < TOTAL_POINTS; ++i) {	//Generates random points and adds it to list
			int x = rand.nextInt(650) + 50;		//Creates a new x value ranging from 50-650
			int y = rand.nextInt(650) + 50;		//Creates a new y value ranging from 50-650
			list.add(new Point(x, y));			//Add the point to the list
		}
	}
	
	//Gets all the points and then uses draw function to add them to the panel
	private void DrawPoint(Graphics g) {
		for(int i = 0; i < TOTAL_POINTS; ++i) {	//Moves through list drawing each point
			Point point = list.get(i);			//save point to save from double lookup
			g.fillOval(point.x-4, point.y-4, 8, 8);	//Subtract 4 so line will end up in middle of point
		}
	}
	
	//I use this to highlight the points from the convex hull
	private void DrawPointH(Graphics g) {
		g.setColor(Color.blue);			//Set Color of Points
		for(int i = 0; i < hull.size(); ++i) {	//Moves through list drawing each point
			Point point = hull.get(i);			//save point to save from double lookup
			g.fillOval(point.x-5, point.y-5, 10, 10);	//Subtract 4 so line will end up in middle of point
		}
	}
	
	//Draws a line from one point to another
	protected void DrawLine(Point a, Point b, Graphics g) { 
		g.drawLine(a.x, a.y, b.x, b.y); 		//Draws the line
	}
	

	//Call the paint function
	@Override
	public void paint(Graphics g) {
		g.setColor(Color.red);			//Set Color of Points
		SetLines(g);					//Calls the Algorithm function and draws lines
		DrawPoint(g);					//Draw the Points
		DrawPointH(g);
	}



}
