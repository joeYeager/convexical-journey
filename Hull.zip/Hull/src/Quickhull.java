
import java.awt.Graphics;
import java.awt.Point;
import java.util.ArrayList;

public class Quickhull extends Panel{
	
	//The idea of the quickhull is to start of finding the the farthest distance on the x axis.
	//
	
	//Default Constructor
	//The paint function from parent will call setLines which does all the work
	public Quickhull() { super(); }
	
	//It gets called by it's parent paint method
	protected void SetLines(Graphics g) {
		hull = new ArrayList<Point>();		//Create the list to store the hull points
		Algorithm();
		for(int i = 0; i < hull.size()-1; ++i)
			DrawLine(hull.get(i), hull.get(i+1), g);
		DrawLine(hull.get(hull.size()-1), hull.get(0), g);
	}
	
	//This function uses the Quickhull algorithm to find the convex hull
	private void Algorithm() {
		if(list.size() < 2) {				//If the list has less then 2 items return error
			System.out.println("There is less then 2 items in the list");
			return;
		}
		
		//I am starting off setting values to first item since all items might be larger then an initial small value of 0
		Point initial = list.get(0);			//Grabs first item to add it to initial values
		int small = initial.x;				//Smallest number in the list
		int smallLoc = 0;					//The location of the smallest item
		int large = initial.x;				//Largest item
		int largeLoc = 0;					//The location of the largest item
		
		//Since first value is already given to values I can start by checking it against second item in list
		for(int i = 1; i < list.size(); ++i) {	//Move through the list finding largest and smallest items
			Point point = list.get(i);		//Create temp point so that it is not looked up multiple times
			if(point.x < small) {			//If this point is smaller then smallest item so far
				small = point.x;			//Set small point to points x value
				smallLoc = i;				//Remember the location of the small value
			}
			else if(point.x > large) {		//If this point is larger then smallest item so far
				large = point.x;			//Set larger point to points x value
				largeLoc = i;				//Remember the location of the large value
			}
		}
		Point pointA = list.get(smallLoc);	//Set the smallest point to pointA
		Point pointB = list.get(largeLoc);	//Set the smallest point to pointA
		hull.add(pointA);					//Add A to the list
		hull.add(pointB);					//Add B to the list
		
		ArrayList<Point> left = new ArrayList<Point>();	//Holds the info to the left of the hull	
		ArrayList<Point> right = new ArrayList<Point>();//Holds the info to the right of the hull		
		for(int i = 0; i < list.size(); ++i) {
			Point p = list.get(i);						//Keep track of point to avoid multiple lookups
			if(Position(pointA, pointB, p) == -1)		//If this is outside the hull add it to left
				left.add(p);
			else
				right.add(p);				//Else add to the right
		}
		
		//Call the recursive Hull function to the right and to the left
		findHull(pointA, pointB, right);
		findHull(pointB, pointA, left);
		
	}
	
	
	//This is a recursive call that will check for the nodes to the left and right
	private void findHull(Point pointA, Point pointB, ArrayList<Point> set) {
		if(set.size() == 0)				//There are no more items left
			return;							//Leave
		if(set.size() == 1) {				//If there is only one item left it is part of the hull
			hull.add(set.get(0));			//Add the point to hull
			set.remove(0);					//Remove that point from the list
			return;							//The function is finished
		}

		int location = farthest(pointA, pointB, set);	//get the location of the farthest point
		Point pointC = set.get(location);		//Keep track of the farthest point
		hull.add(pointC);						//Add the point to hull
		set.remove(location);					//Remove that point from the list
		
		ArrayList<Point> left = CheckPosition(pointA, pointC, set); //Holds the info to the left of A and C
		ArrayList<Point> right = CheckPosition(pointC, pointB, set); //Holds the info to the right of B and C
		
		findHull(pointA, pointC, left);		//Call the recursive function to the left
		findHull(pointC, pointB, right);	//Call the recursive function to the right
	}
	
	//This will recurse through the list sent in and find if points are outside the hull using Position function
	//It should not be bad to return the array since it is only a pointer
	private ArrayList<Point> CheckPosition(Point pointA, Point pointB, ArrayList<Point> set) {
		ArrayList<Point> outside = new ArrayList<Point>();	//Holds the info outside the hull		
		for(int i = 0; i < set.size(); ++i) {
			Point pointD = set.get(i);			//Keep track of point to avoid multiple lookups
			if(Position(pointA, pointB, pointD) == 1)	//If this is outside the hull add it to left
				outside.add(pointD);
		}
		return outside;
	}
	
	
	
	//Uses the two Original points a and b locations to find the farthest point from that location
	protected int farthest(Point pointA, Point pointB, ArrayList<Point> set) {
		int location = 0;			//Keeps track of the current largest location
		int value = 0;				//Keeps track of the current largest value
		
		//Searches the list for farthest point
		for(int i = 2; i < set.size(); ++i) {
			int x = Distance(pointA, pointB, set.get(i));	//Gets distance of this point
			if(x > value) {			//If this point is the greatest so far remember value and location
				value = x;
				location = i;
			}
		}
		return location;			//Return location of farthest point
	}
	
	//Got formula from http://www.ahristov.com/tutorial/geometry-games/convex-hull.html
	//Returns the distance of point C from Points A and B
	protected int Distance(Point pointA, Point pointB, Point pointC) {
		int ABx = pointB.x - pointA.x;			//Gets distance between x values
		int ABy = pointB.y - pointB.y;			//Gets distance between y values
		int dist = (ABx*(pointA.y-pointC.y))-(ABy*(pointA.x-pointC.x));		//Gets distance
		if(dist < 0)							//If distance is negative make it positive
			dist = -dist;
		return dist;
	}
	
	//This is similar to distance, except it returns a 1 or -1
	//And it also has PointC - PointA
	//I got the formula also from http://www.ahristov.com/tutorial/geometry-games/convex-hull.html
	protected int Position(Point pointA, Point pointB, Point pointC) {
		int ABx = pointB.x - pointA.x;			//Gets distance between x values
		int ABy = pointB.y - pointA.y;			//Gets distance between y values
		int dist = (ABx*(pointC.y-pointA.y))-(ABy*(pointC.x-pointA.x));		//Gets distance
		if(dist > 0)							//If distance is greater then 0 return 1 else return -1
			return 1;
		return -1;
	}
}
