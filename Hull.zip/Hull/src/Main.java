import javax.swing.JFrame;

import java.awt.Color;
import java.awt.color.*;

public class Main {
	public static void main(String[] args) {

		setUpFrame(new Quickhull());							//Runs the quickhull agorithm
		
	}
	
	//Sets up the frame and runs the program
	private static int setUpFrame(Panel pan) {
		JFrame frame = new JFrame();							//Creates the frame
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	//Sets what happens when frame closes
		frame.setSize(800, 800);								//Sets frame's size
		frame.setTitle("Convex Hull Test");						//Sets the Title to the frame
		frame.setBackground(Color.DARK_GRAY);					//Sets the background color
		frame.add(pan);											//Adds the panel sent in into the frame
		frame.setVisible(true);									//Makes the frame visible
		
		return 1;
		
	}
}
